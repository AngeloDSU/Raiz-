package br.com.raizplus;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.plugin.java.JavaPlugin;

public final class RaizPlusPlugin extends JavaPlugin {
    private static final String PREFIX = ChatColor.GREEN + "√ " + ChatColor.BOLD + "Raiz+"
            + ChatColor.DARK_GRAY + " » " + ChatColor.RESET;

    @Override
    public void onEnable() {
        getLogger().info("Raiz+ ativado! Permissões compatíveis com Bukkit e LuckPerms.");
    }

    @Override
    public void onDisable() {
        getLogger().info("Raiz+ desativado.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Bukkit resolve as permissões; LuckPerms pode gerenciá-las sem dependência direta.
        if (!sender.hasPermission("raizplus.use")) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Você não tem permissão para usar este comando.");
            return true;
        }

        if (args.length == 0 || args[0].equalsIgnoreCase("ajuda")) {
            sendHelp(sender);
            return true;
        }
        if (args.length != 1) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Use: /raiz <número>");
            sender.sendMessage(ChatColor.GRAY + "Exemplo: /raiz 144");
            return true;
        }

        String raw = args[0].replace(',', '.');
        final BigDecimal input;
        try {
            input = new BigDecimal(raw);
        } catch (NumberFormatException exception) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Número inválido. Exemplo: /raiz 144 ou /raiz 2,5");
            return true;
        }

        if (input.signum() < 0) {
            sender.sendMessage(PREFIX + ChatColor.RED + "A raiz quadrada de um número negativo não existe nos números reais.");
            return true;
        }

        double value = input.doubleValue();
        if (!Double.isFinite(value)) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Esse número é grande demais para calcular.");
            return true;
        }
        double root = Math.sqrt(value);
        if (!Double.isFinite(root)) {
            sender.sendMessage(PREFIX + ChatColor.RED + "Não foi possível calcular esse número.");
            return true;
        }

        String formattedInput = format(value, 8);
        boolean exactIntegerRoot = root == Math.rint(root)
                && BigDecimal.valueOf(root).multiply(BigDecimal.valueOf(root))
                    .compareTo(input.stripTrailingZeros()) == 0;

        if (exactIntegerRoot) {
            sender.sendMessage(PREFIX + ChatColor.WHITE + "A raiz quadrada de "
                    + ChatColor.AQUA + formattedInput + ChatColor.WHITE + " é "
                    + ChatColor.YELLOW + format(root, 0) + ChatColor.WHITE + "!");
            sender.sendMessage(ChatColor.GREEN + "✓ " + ChatColor.GRAY + "Resultado exato!");
        } else {
            sender.sendMessage(PREFIX + ChatColor.WHITE + "A raiz quadrada de "
                    + ChatColor.AQUA + formattedInput + ChatColor.WHITE + " é aproximadamente "
                    + ChatColor.YELLOW + format(root, 10) + ChatColor.WHITE + ".");
            sender.sendMessage(ChatColor.GRAY + "ⓘ Resultado aproximado (até 10 casas decimais).");
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage(ChatColor.DARK_GREEN + "" + ChatColor.BOLD + "────── √ Raiz+ ──────");
        sender.sendMessage(ChatColor.WHITE + "A calculadora de raiz quadrada do seu servidor!");
        sender.sendMessage(ChatColor.GREEN + "/raiz <número> " + ChatColor.GRAY + "— calcula a raiz quadrada");
        sender.sendMessage(ChatColor.GREEN + "/raiz ajuda " + ChatColor.GRAY + "— mostra esta ajuda");
        sender.sendMessage(ChatColor.GREEN + "/sqrt <número> " + ChatColor.GRAY + "— alias do comando principal");
        sender.sendMessage(ChatColor.DARK_GREEN + "" + ChatColor.BOLD + "Mais do que números... É a raiz do seu servidor!");
    }

    private String format(double value, int maxFractionDigits) {
        DecimalFormatSymbols symbols = DecimalFormatSymbols.getInstance(Locale.forLanguageTag("pt-BR"));
        DecimalFormat format = new DecimalFormat("#,##0", symbols);
        if (maxFractionDigits > 0) {
            format.setMinimumFractionDigits(0);
            format.setMaximumFractionDigits(maxFractionDigits);
            format.setRoundingMode(RoundingMode.HALF_UP);
        }
        return format.format(value);
    }
}
