# Raiz+ 1.0.1 — compatibilidade com LuckPerms

Plugin de calculadora de raiz quadrada para servidores Minecraft Java com API Bukkit/Paper. Mensagens aos jogadores em PT-BR.

## LuckPerms
O Raiz+ usa a API de permissões padrão do Bukkit (`CommandSender#hasPermission`) e declara o nó `raizplus.use` no `plugin.yml`. LuckPerms gerencia esse nó normalmente; o Raiz+ não precisa importar a API LuckPerms nem ter uma dependência obrigatória dela.

A permissão está com `default: false`, então o administrador deve concedê-la explicitamente.

Exemplos para executar no console do servidor:
```text
lp group default permission set raizplus.use true
lp group vip permission set raizplus.use true
lp group default permission set raizplus.use false
lp user NOME_DO_JOGADOR permission set raizplus.use true
```
Escolha a política que deseja. Os exemplos acima são alternativas, não execute todos indiscriminadamente. Se quiser que todos usem o plugin, conceda ao grupo padrão:
```text
lp group default permission set raizplus.use true
```
Para um acesso restrito a VIP, conceda ao grupo VIP e não conceda ao grupo padrão:
```text
lp group vip permission set raizplus.use true
```
O LuckPerms usa nós de permissão para conceder ou negar acesso e permite atribuí-los a usuários e grupos: https://luckperms.net/wiki/Usage

## Comandos
- `/raiz <número>`
- `/sqrt <número>` (alias)
- `/raiz ajuda`
- Aceita vírgula ou ponto decimal.

## Compilar
Requer JDK 25 e Maven 3.9+:
```bash
mvn clean package
```
Saída: `target/RaizPlus-1.0.1.jar`

## Instalar e testar
1. Pare o servidor.
2. Coloque o JAR em `plugins/`.
3. Inicie o servidor.
4. Confirme que `RaizPlus` e `LuckPerms` carregaram sem erros.
5. Conceda `raizplus.use` com um dos comandos acima.
6. Teste `/raiz 144`, `/sqrt 81` e teste com um jogador sem permissão.

## Compatibilidade
O projeto está configurado com Java 25 e Paper API `1.21.11-R0.1-SNAPSHOT`. Isso não comprova compatibilidade com Paper/Spigot 26.x. Para distribuição, ajuste a API de compilação para a versão exata do servidor de destino e compile/teste nela. Este projeto ainda não foi compilado nem validado em servidor real.
